import UIKit

let multiplyTwoInts = ({ (numb1: Int , numb2: Int) -> Int in
    return numb1 * numb2
  
})
let result = multiplyTwoInts(15,3)
print(result)
